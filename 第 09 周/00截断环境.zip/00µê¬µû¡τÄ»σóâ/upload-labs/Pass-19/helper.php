<?php
if($_GET['action'] == 'get_prompt'){
    echo '本pass的取文件名通过$_POST来获取。';
}
?>