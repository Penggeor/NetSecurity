<?php
if($_GET['action'] == 'get_prompt'){
    echo '本pass只允许上传.jpg|.png|.gif后缀的文件！';
}
?>