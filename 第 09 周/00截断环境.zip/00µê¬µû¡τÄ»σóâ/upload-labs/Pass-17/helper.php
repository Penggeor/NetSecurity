<?php
if($_GET['action'] == 'get_prompt'){
    echo '需要代码审计！';
}
?>